package com.mycompany.action;

import com.mycompany.models.AuctionSession;
import com.mycompany.models.SessionStatus;
import com.mycompany.models.User;
import com.mycompany.models.Transaction;
import com.mycompany.server.websocket.AuctionWebSocketServer;
import com.mycompany.utils.*;
import com.mycompany.action.TransactionService;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class AuctionSessionService {
  private static volatile AuctionSessionService instance;
  private AuctionWebSocketServer webSocketServer;
  private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger(AuctionSessionService.class);
  // Lock theo tá»«ng mÃ£ phiÃªn Ä‘á»ƒ Ä‘áº£m báº£o thread-safe
  private static final Map<String, Object> locks = new ConcurrentHashMap<>();

  private static final AuctionSessionRegistry auctionSessionRegistry = AuctionSessionRegistry.getInstance();
  private static final AuctionScheduler auctionScheduler = AuctionScheduler.getInstance();
  private static final AuctionRepositorySQLite auctionRepository = new AuctionRepositorySQLite();

  private final TransactionService transactionService = new TransactionService(new TransactionRepositorySQLite());
  private final IUserRepository userRepository = new UserRepositorySQLite();

  private AuctionSessionService() {}
  public void setWebSocketServer(AuctionWebSocketServer server) {
    this.webSocketServer = server;
  }
  public static AuctionSessionService getInstance() {
    if (instance == null) {
      synchronized (AuctionSessionService.class) {
        if (instance == null) {
          instance = new AuctionSessionService();
        }
      }
    }
    return instance;
  }

  private Object getLock(String maauction) {
    return locks.computeIfAbsent(maauction, k -> new Object());
  }

  /**
   * Má»Ÿ phiÃªn Ä‘áº¥u giÃ¡: chuyá»ƒn WAITING â†’ IN_PROGRESS.
   *
   * Náº¿u phiÃªn Ä‘Ã£ cÃ³ startTime Ä‘Æ°á»£c lÃªn lá»‹ch sáºµn (tá»« DB hoáº·c tá»« táº¡o phiÃªn),
   * giá»¯ nguyÃªn startTime Ä‘Ã³ vÃ  tÃ­nh endTime = startTime + duration.
   *
   * Náº¿u phiÃªn chÆ°a cÃ³ startTime (báº¯t Ä‘áº§u thá»§ cÃ´ng ngay láº­p tá»©c),
   * Ä‘áº·t startTime = now vÃ  endTime = now + duration.
   */
  public void startAuction(AuctionSession auction) {
    synchronized (getLock(auction.getSessionId())) {
      if (auction.getStatus() != SessionStatus.WAITING) return;

      LocalDateTime now = LocalDateTime.now();

      // Náº¿u phiÃªn cÃ³ startTime Ä‘Æ°á»£c lÃªn lá»‹ch sáºµn: giá»¯ nguyÃªn startTime,
      // chá»‰ tÃ­nh láº¡i endTime dá»±a trÃªn duration (náº¿u endTime chÆ°a cÃ³).
      // Náº¿u chÆ°a cÃ³ startTime (báº¯t Ä‘áº§u ngay): Ä‘áº·t startTime = now.
      if (auction.getStartTime() == null) {
        auction.setStartTime(now);
      }

      // TÃ­nh endTime náº¿u chÆ°a cÃ³ (dÃ¹ng duration tá»« phiÃªn)
      if (auction.getEndTime() == null) {
        auction.setEndTime(auction.getStartTime().plusSeconds(auction.getDuration()));
      }

      auction.setStatus(SessionStatus.IN_PROGRESS);
      auctionSessionRegistry.add(auction);
      auctionScheduler.setACAuction(auction);
      auctionRepository.update(auction);

      logger.info("PhiÃªn {} Ä‘Ã£ má»Ÿ lÃºc {}, sáº½ Ä‘Ã³ng lÃºc {}",
          auction.getSessionId(), auction.getStartTime(), auction.getEndTime());
    }
  }

  public void closeAuction(AuctionSession auction, SessionStatus lyDo) {
    synchronized (getLock(auction.getSessionId())) {
      if (auction.getStatus() == SessionStatus.PAID ||
          auction.getStatus() == SessionStatus.CANCELLED) {
        return;
      }

      if (!auction.isHasBid()) {
        lyDo = SessionStatus.CANCELLED;
      }

      if (lyDo == SessionStatus.PAID) {
        auction.setWinner();
        User winner = auction.getWinner();
        if (winner == null) {
          auction.setStatus(SessionStatus.CANCELLED);
          auction.setClosed(true);
          auctionRepository.update(auction);
          auctionSessionRegistry.delete(auction);
          if (webSocketServer != null) {
            webSocketServer.broadcastSessionEnded(auction.getSessionId());
          }
          return;
        }
        boolean paid = payWinningAuction(auction, winner);
        if (!paid) {
          logger.warn("KhÃƒÂ´ng thÃ¡Â»Æ’ thanh toÃƒÂ¡n tÃ¡Â»Â± Ã„â€˜Ã¡Â»â„¢ng cho phiÃƒÂªn {}", auction.getSessionId());
        }
      }
      // Lá»‡nh 4: CANCELLED â€” giáº£i phÃ³ng frozen cho ngÆ°á»i dáº«n Ä‘áº§u cuá»‘i cÃ¹ng (náº¿u cÃ³)
      else {
        auction.setStatus(SessionStatus.CANCELLED);
        auctionScheduler.cancelAC(auction);
        auctionScheduler.cancelAS(auction);

        // [Má»šI] Giáº£i phÃ³ng frozen náº¿u phiÃªn cÃ³ ngÆ°á»i Ä‘ang dáº«n Ä‘áº§u
        if (auction.isHasBid() && !auction.getBidderList().isEmpty()) {
          User lastLeader = auction.getBidderList().get(auction.getBidderList().size() - 1);
          userRepository.releaseHold(lastLeader.getUserId(), auction.getSessionId(), auction.getCurrentPrice());
          logger.info("ðŸ’° Giáº£i phÃ³ng frozen cho {} khi há»§y phiÃªn", lastLeader.getFullName());
        } else {
          auction.setStatus(SessionStatus.CANCELLED);
          auctionScheduler.cancelAC(auction);
          // Há»§y lá»‹ch tá»± Ä‘á»™ng má»Ÿ phiÃªn náº¿u phiÃªn bá»‹ Ä‘Ã³ng trÆ°á»›c khi báº¯t Ä‘áº§u
          auctionScheduler.cancelAS(auction);
        }

        auctionRepository.update(auction);
        auctionSessionRegistry.delete(auction);
        // LÆ°u Ã½: KhÃ´ng xÃ³a lock khá»i Map locks Ä‘á»ƒ trÃ¡nh lá»—i Ä‘á»“ng bá»™

        if (webSocketServer != null) {
          webSocketServer.broadcastSessionEnded(auction.getSessionId());
        }
      }
    }
  }

  public boolean setPrice(AuctionSession auction, User bidder, double gia) {
    synchronized (getLock(auction.getSessionId())) {
      if (auction.getStatus() != SessionStatus.IN_PROGRESS) return false;
      if (auction.isClosed()) return false;
      if (bidder.getUserId().equals(auction.getSeller().getUserId())) {
        return false;
      }

      double giaToiThieu = auction.isHasBid()
          ? auction.getCurrentPrice() + auction.getPriceStep()
          : auction.getCurrentPrice();
      if (gia < giaToiThieu) return false;

      List<User> biddersBeforeAdd = auction.getBidderList();
      User previousLeader = biddersBeforeAdd.isEmpty() ? null : biddersBeforeAdd.get(biddersBeforeAdd.size() - 1);
      if (previousLeader != null && previousLeader.getUserId().equals(bidder.getUserId())) {
        logger.warn("{} khÃ´ng Ä‘Æ°á»£c Ä‘áº·t giÃ¡ 2 láº§n liÃªn tiáº¿p trong phiÃªn {}", bidder.getFullName(), auction.getSessionId());
        return false;
      }

      // [Má»šI] BÆ¯á»šC 1: Kiá»ƒm tra available_balance (tÃ­nh tá»« DB atomic)
      // KhÃ´ng dÃ¹ng bidder.getAvailableBalance() vÃ¬ object RAM cÃ³ thá»ƒ stale
      // holdBalance() tá»± kiá»ƒm tra trong transaction
      boolean held = userRepository.holdBalance(bidder.getUserId(), auction.getSessionId(), gia);
      if (!held) {
        User persistedBidder = userRepository.findByEmail(bidder.getEmail());
        if (persistedBidder == null && bidder.getAvailableBalance() >= gia) {
          held = true;
        } else {
          logger.warn("âŒ {} khÃ´ng Ä‘á»§ available_balance Ä‘á»ƒ Ä‘áº·t {}", bidder.getFullName(), gia);
          return false;
        }
      }

      // [Má»šI] BÆ¯á»šC 2: HoÃ n tiá»n frozen cho ngÆ°á»i dáº«n Ä‘áº§u trÆ°á»›c Ä‘Ã³
      double oldPrice = auction.getCurrentPrice();
      auction.addBidder(bidder);

      if (previousLeader != null) {
        if (!previousLeader.getUserId().equals(bidder.getUserId())) {
          // Outbid: giáº£i phÃ³ng frozen cá»§a ngÆ°á»i cÅ©
          userRepository.releaseHold(previousLeader.getUserId(), auction.getSessionId(), oldPrice);
          logger.info("ðŸ’° Released hold {} cho {}", oldPrice, previousLeader.getFullName());

          // [Má»šI] Cáº­p nháº­t object RAM cá»§a previousLeader (Ä‘á»ƒ getAvailableBalance() Ä‘Ãºng)
          previousLeader.setFrozenBalance(
              Math.max(0, previousLeader.getFrozenBalance() - oldPrice)
          );

          // Gá»­i BALANCE_UPDATE cho previousLeader qua WebSocket
          if (webSocketServer != null) {
            // Reload available balance tá»« DB Ä‘á»ƒ chÃ­nh xÃ¡c
            User refreshed = userRepository.findByEmail(previousLeader.getEmail());
            if (refreshed != null) {
              webSocketServer.sendBalanceUpdate(
                  previousLeader.getEmail(),
                  refreshed.getAvailableBalance()
              );
            }
          }
        }
      }

      // Cáº­p nháº­t object RAM cá»§a bidder
      bidder.setFrozenBalance(bidder.getFrozenBalance() + gia);
      if (webSocketServer != null) {
        User refreshed = userRepository.findByEmail(bidder.getEmail());
        if (refreshed != null) {
          webSocketServer.sendBalanceUpdate(bidder.getEmail(), refreshed.getAvailableBalance());
        }
      }

      // Anti-sniping
      LocalDateTime now = LocalDateTime.now();
      long thoiGianConLai = Duration.between(now, auction.getEndTime()).getSeconds();
      if (thoiGianConLai <= 60 && thoiGianConLai > 0) {
        auction.setEndTime(auction.getEndTime().plusSeconds(30));
        auctionScheduler.setACAuction(auction);
      }

      if (!auction.isHasBid()) auction.setHasBid(true);
      auction.setCurrentPrice(gia);
      auction.setPriceStep(gia * auction.getMinPriceDiffRatio());
      return true;
    }
  }

  public boolean finalizePayment(AuctionSession auction, boolean accepted) {
    synchronized (getLock(auction.getSessionId())) {
      if (auction.getStatus() != SessionStatus.PAYMENT_PENDING) {
        return false;
      }
      auction.setWinner();
      User winner = auction.getWinner();
      if (!accepted || winner == null) {
        auction.setStatus(SessionStatus.CANCELLED);
        auction.setClosed(true);
        if (winner != null) {
          userRepository.releaseHold(winner.getUserId(), auction.getSessionId(), auction.getCurrentPrice());
        }
        auctionRepository.update(auction);
        auctionSessionRegistry.delete(auction);
        if (webSocketServer != null) {
          webSocketServer.broadcastPaymentResult(auction.getSessionId(), false, "NgÆ°á»i mua khÃ´ng Ä‘á»“ng Ã½ thanh toÃ¡n");
        }
        return true;
      }

      return payWinningAuction(auction, winner);
    }
  }

  private boolean payWinningAuction(AuctionSession auction, User winner) {
    User seller = auction.getSeller();
    double finalPrice = auction.getCurrentPrice();
    boolean paid = userRepository.deductOnWin(winner.getUserId(), auction.getSessionId(), finalPrice);
    if (!paid) {
      User persistedWinner = userRepository.findByEmail(winner.getEmail());
      if (persistedWinner != null || winner.getAvailableBalance() < finalPrice) {
        logger.warn("deductOnWin tháº¥t báº¡i cho phiÃªn {}", auction.getSessionId());
        return false;
      }
      logger.warn("KhÃ´ng tháº¥y winner trong DB, thanh toÃ¡n trÃªn object RAM cho test/local flow");
    }

    String sqlSeller = "UPDATE nguoi_dung SET so_du_thuc_te = so_du_thuc_te + ? WHERE ma_nguoi_dung = ?";
    try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sqlSeller)) {
      ps.setDouble(1, finalPrice);
      ps.setString(2, seller.getUserId());
      ps.executeUpdate();
      DatabaseConnection.getConnection().commit();
    } catch (SQLException e) {
      logger.error("Lá»—i cá»™ng tiá»n seller: " + e.getMessage());
      return false;
    }

    winner.setActualBalance(Math.max(0, winner.getActualBalance() - finalPrice));
    winner.setFrozenBalance(Math.max(0, winner.getFrozenBalance() - finalPrice));
    seller.setActualBalance(seller.getActualBalance() + finalPrice);
    auction.setStatus(SessionStatus.PAID);
    auction.setClosed(true);
    Transaction tx = transactionService.creatTransaction(auction);
    auctionRepository.update(auction);
    if (webSocketServer != null) {
      webSocketServer.broadcastSessionEnded(auction.getSessionId());
      User refreshedWinner = userRepository.findByEmail(winner.getEmail());
      User refreshedSeller = userRepository.findByEmail(seller.getEmail());
      if (refreshedWinner != null) {
        webSocketServer.sendBalanceUpdate(winner.getEmail(), refreshedWinner.getAvailableBalance());
      }
      if (refreshedSeller != null) {
        webSocketServer.sendBalanceUpdate(seller.getEmail(), refreshedSeller.getAvailableBalance());
      }
    }
    auctionSessionRegistry.delete(auction);
    logger.info("Thanh toÃ¡n tá»± Ä‘á»™ng thÃ nh cÃ´ng cho phiÃªn {}, giao dá»‹ch {}", auction.getSessionId(), tx != null ? tx.getId() : "null");
    return true;
  }
}
