package com.mycompany.action;

import java.util.HashMap;
import java.util.Map;

import com.mycompany.models.User;
import com.mycompany.utils.UserProfileUpdater;
import com.mycompany.utils.IUserRepository;
import com.mycompany.utils.UserRepositorySQLite;
import com.mycompany.utils.SessionManager;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

/**
 * FinanceAction - Class xá»­ lÃ½ cÃ¡c thao tÃ¡c tÃ i chÃ­nh
 *
 * Má»¤C ÄÃCH:
 * - Quáº£n lÃ½ cÃ¡c chá»©c nÄƒng tÃ i chÃ­nh cá»§a ngÆ°á»i dÃ¹ng
 * - Xá»­ lÃ½ náº¡p tiá»n vÃ  rÃºt tiá»n
 * - Cáº­p nháº­t sá»‘ dÆ° tÃ i khoáº£n
 * - Validate cÃ¡c thao tÃ¡c tÃ i chÃ­nh
 *
 * Káº¾T Ná»I Vá»šI CONTROLLER:
 * - FinanceController gá»i cÃ¡c phÆ°Æ¡ng thá»©c cá»§a FinanceAction
 * - FinanceController.onClickedDeposit() â†’ FinanceAction.deposit()
 * - FinanceController.onClickedWithdraw() â†’ FinanceAction.withdraw()
 * - FinanceController.onClickedEditBankAccount() â†’ FinanceAction.editBankAccount()
 *
 * TÃNH NÄ‚NG CHÃNH:
 * - Náº¡p tiá»n: Cá»™ng tiá»n vÃ o sá»‘ dÆ°, cáº­p nháº­t database
 * - RÃºt tiá»n: Trá»« tiá»n tá»« sá»‘ dÆ° (kiá»ƒm tra Ä‘á»§ tiá»n), cáº­p nháº­t database
 * - Edit bank account: Enable/disable editing mode cho TextField
 * - Validation: Kiá»ƒm tra sá»‘ tiá»n há»£p lá»‡, sá»‘ dÆ° Ä‘á»§ Ä‘á»ƒ rÃºt
 *
 * DESIGN PATTERN:
 * - Singleton: Chá»‰ cÃ³ 1 instance FinanceAction
 * - Business Logic Layer: TÃ¡ch logic kinh doanh ra khá»i UI controller
 */
public class FinanceAction {
    private final IUserRepository khoLuuTruNguoiDung = new UserRepositorySQLite();

    private FinanceAction() {}

    /**
     * getInstance() - Singleton pattern
     * Äáº£m báº£o chá»‰ cÃ³ 1 instance FinanceAction trong toÃ n bá»™ á»©ng dá»¥ng
     *
     * @return Instance duy nháº¥t cá»§a FinanceAction
     */
    private static volatile FinanceAction instance;
    public static FinanceAction getInstance() {
        if (instance == null) {
            synchronized (FinanceAction.class) {
                if (instance == null) instance = new FinanceAction();
            }
        }
        return instance;
    }

    /**
     * editBankAccount(TextField field, boolean editing) - Báº­t/táº¯t cháº¿ Ä‘á»™ chá»‰nh sá»­a tÃ i khoáº£n ngÃ¢n hÃ ng
     *
     * Káº¾T Ná»I Vá»šI CONTROLLER:
     * - ÄÆ°á»£c gá»i tá»« FinanceController.onClickedEditBankAccount()
     * - Khi ngÆ°á»i dÃ¹ng click nÃºt edit bÃªn cáº¡nh Ã´ nháº­p tÃ i khoáº£n
     *
     * CHá»¨C NÄ‚NG:
     * - editing = true: Cho phÃ©p nháº­p text, focus vÃ o field
     * - editing = false: KhÃ³a field, khÃ´ng cho nháº­p
     *
     * @param field TextField cáº§n chá»‰nh sá»­a (bankAccount field)
     * @param editing true = enable editing, false = disable editing
     */
    public void editBankAccount(TextField field, boolean editing) {
        field.setEditable(editing);
        field.setOpacity(1.0); // set láº¡i Ã­t má» hÆ¡n
        if (editing) {
            field.requestFocus(); // tá»± Ä‘á»™ng focus vÃ o Ã´ khi báº¯t Ä‘áº§u chá»‰nh sá»­a
        }
    }

    /**
     * deposit(double amount) - Xá»­ lÃ½ náº¡p tiá»n vÃ o tÃ i khoáº£n
     *
     * Káº¾T Ná»I Vá»šI CONTROLLER:
     * - ÄÆ°á»£c gá»i tá»« FinanceController.onClickedDeposit()
     * - Khi ngÆ°á»i dÃ¹ng nháº­p sá»‘ tiá»n vÃ  click nÃºt "Náº¡p tiá»n"
     *
     * QUY TRÃŒNH:
     * 1. Validate sá»‘ tiá»n (> 0)
     * 2. Láº¥y ngÆ°á»i dÃ¹ng hiá»‡n táº¡i tá»« SessionManager
     * 3. TÃ­nh sá»‘ dÆ° má»›i = sá»‘ dÆ° cÅ© + sá»‘ tiá»n náº¡p
     * 4. Táº¡o Map chá»©a update (balance)
     * 5. Gá»i CapNhatThongTinNguoiDung.updateUser() Ä‘á»ƒ lÆ°u
     * 6. Hiá»ƒn thá»‹ thÃ´ng bÃ¡o thÃ nh cÃ´ng
     *
     * Xá»¬ LÃ Lá»–I:
     * - Sá»‘ tiá»n <= 0 â†’ NumberFormatException â†’ thÃ´ng bÃ¡o lá»—i
     *
     * @param amount Sá»‘ tiá»n cáº§n náº¡p (pháº£i > 0)
     */
    public void deposit(double amount) {
        try {
            if (amount <= 0) {
                throw new NumberFormatException();
            }
            User currentUser = SessionManager.getInstance().getCurrentUser(); // láº¥y ngÆ°á»i dÃ¹ng hiá»‡n táº¡i
            double newBalance = currentUser.getActualBalance() + amount; // cá»™ng thÃªm sá»‘ tiá»n thÃªm vÃ o
            Map<String, String> updateBalance = new HashMap<>();
            updateBalance.put("actualBalance", String.valueOf(newBalance));
            UserProfileUpdater.getInstance().updateUser(updateBalance); // táº¡o map Ä‘á»ƒ update

            HandleNavigationAndAlert.getInstance().showAlert(Alert.AlertType.INFORMATION, "ThÃ nh cÃ´ng", "Náº¡p tiá»n thÃ nh cÃ´ng!");
        } catch (NumberFormatException e) {
            HandleNavigationAndAlert.getInstance().showAlert(Alert.AlertType.ERROR, "Lá»—i thÃ´ng tin", "Sá»‘ tiá»n náº¡p khÃ´ng há»£p lá»‡! Vui lÃ²ng nháº­p láº¡i.");
        }
    }

    /**
     * withdraw(double amount) - Xá»­ lÃ½ rÃºt tiá»n tá»« tÃ i khoáº£n
     *
     * Káº¾T Ná»I Vá»šI CONTROLLER:
     * - ÄÆ°á»£c gá»i tá»« FinanceController.onClickedWithdraw()
     * - Khi ngÆ°á»i dÃ¹ng nháº­p sá»‘ tiá»n vÃ  click nÃºt "RÃºt tiá»n"
     *
     * QUY TRÃŒNH:
     * 1. Validate sá»‘ tiá»n (> 0)
     * 2. Láº¥y ngÆ°á»i dÃ¹ng hiá»‡n táº¡i vÃ  sá»‘ dÆ° hiá»‡n táº¡i
     * 3. Kiá»ƒm tra sá»‘ dÆ° Ä‘á»§ Ä‘á»ƒ rÃºt (amount <= currentBalance)
     * 4. TÃ­nh sá»‘ dÆ° má»›i = sá»‘ dÆ° cÅ© - sá»‘ tiá»n rÃºt
     * 5. Táº¡o Map chá»©a update (balance)
     * 6. Gá»i CapNhatThongTinNguoiDung.updateUser() Ä‘á»ƒ lÆ°u
     * 7. Hiá»ƒn thá»‹ thÃ´ng bÃ¡o thÃ nh cÃ´ng
     *
     * Xá»¬ LÃ Lá»–I:
     * - Sá»‘ tiá»n <= 0 â†’ NumberFormatException â†’ thÃ´ng bÃ¡o lá»—i
     * - Sá»‘ dÆ° khÃ´ng Ä‘á»§ â†’ Alert lá»—i "Sá»‘ tiá»n rÃºt vÆ°á»£t quÃ¡ sá»‘ dÆ° hiá»‡n táº¡i"
     *
     * @param amount Sá»‘ tiá»n cáº§n rÃºt (pháº£i > 0 vÃ  <= sá»‘ dÆ° hiá»‡n táº¡i)
     */
    public void withdraw(double amount) {
        User currentUser = SessionManager.getInstance().getCurrentUser();
        double currentBalance = currentUser.getAvailableBalance();
        try {
            if (amount <=0) {
                throw new NumberFormatException();
            } else if (amount > currentBalance) {
                HandleNavigationAndAlert.getInstance().showAlert(Alert.AlertType.ERROR, "Lá»—i thÃ´ng tin", "Sá»‘ tiá»n rÃºt vÆ°á»£t quÃ¡ sá»‘ dÆ° hiá»‡n táº¡i!");
                return;
            }
            double newBalance = currentUser.getActualBalance() - amount;
            Map<String, String> updateBalance = new HashMap<>();
            updateBalance.put("actualBalance", String.valueOf(newBalance));
            UserProfileUpdater.getInstance().updateUser(updateBalance); // táº¡o map Ä‘á»ƒ update
            HandleNavigationAndAlert.getInstance().showAlert(Alert.AlertType.INFORMATION, "ThÃ nh cÃ´ng", "RÃºt tiá»n thÃ nh cÃ´ng!");
        } catch (NumberFormatException e) {
            HandleNavigationAndAlert.getInstance().showAlert(Alert.AlertType.ERROR, "Lá»—i thÃ´ng tin", "Sá»‘ tiá»n rÃºt khÃ´ng há»£p lá»‡! Vui lÃ²ng nháº­p láº¡i.");
        }
    }
}

