package com.mycompany.utils;
import com.mycompany.action.HandleNavigationAndAlert;
import com.mycompany.models.User;
import javafx.scene.control.Alert;


import java.util.Map;
import java.util.prefs.Preferences; // save thong tin sau khi app dong

/**
 * CapNhatThongTinNguoiDung - Utility class Ä‘á»ƒ cáº­p nháº­t thÃ´ng tin ngÆ°á»i dÃ¹ng
 *
 * Má»¤C ÄÃCH:
 * - Quáº£n lÃ½ viá»‡c cáº­p nháº­t thÃ´ng tin ngÆ°á»i dÃ¹ng tá»« giao diá»‡n (UI) vÃ o há»‡ thá»‘ng
 * - Cáº­p nháº­t cáº£ dá»¯ liá»‡u trong sessionManager vÃ  file JSON
 * - CÆ¡ cháº¿ Singleton Ä‘á»ƒ Ä‘áº£m báº£o chá»‰ cÃ³ má»™t instance duy nháº¥t
 *
 * TÃNH NÄ‚NG CHÃNH:
 * - Cáº­p nháº­t: TÃªn, SÄT, Äá»‹a chá»‰, TÃ i khoáº£n ngÃ¢n hÃ ng, Sá»‘ dÆ°, TÃªn ngÃ¢n hÃ ng
 * - Tá»± Ä‘á»™ng lÆ°u vÃ o file JSON Ä‘á»ƒ dá»¯ liá»‡u bá»n vá»¯ng
 * - Cáº­p nháº­t token JWT sau khi thay Ä‘á»•i thÃ´ng tin
 * - Hiá»ƒn thá»‹ thÃ´ng bÃ¡o lá»—i cho ngÆ°á»i dÃ¹ng
 */
public class UserProfileUpdater {

    // Singleton instance - Ä‘áº£m báº£o chá»‰ cÃ³ má»™t CapNhatThongTinNguoiDung trong suá»‘t á»©ng dá»¥ng

    // Preferences lÃ  Java API Ä‘á»ƒ lÆ°u trá»¯ cÃ i Ä‘áº·t á»©ng dá»¥ng an toÃ n (dÃ¹ng registry trÃªn Windows)
    // LÆ°u trá»¯ auth_token Ä‘á»ƒ khÃ´i phá»¥c session sau khi app Ä‘Ã³ng
    private static final Preferences prefs =
        Preferences.userNodeForPackage(UserProfileUpdater.class);

    // Interface Ä‘á»ƒ lÆ°u trá»¯ dá»¯ liá»‡u ngÆ°á»i dÃ¹ng - hiá»‡n táº¡i dÃ¹ng JSON
    // CÃ³ thá»ƒ thay tháº¿ báº±ng database trong tÆ°Æ¡ng lai (design pattern: Strategy)
    private final IUserRepository userRepository = new UserRepositorySQLite();

    /**
     * Constructor private Ä‘á»ƒ ngÄƒn táº¡o instance trá»±c tiáº¿p
     * NgÆ°á»i dÃ¹ng pháº£i dÃ¹ng getInstance() Ä‘á»ƒ cÃ³ Ä‘Æ°á»£c instance duy nháº¥t
     */
    private UserProfileUpdater() {}

    /**
     * PHÆ¯Æ NG THá»¨C: getInstance()
     * Má»¤C ÄÃCH: Singleton pattern - Ä‘áº£m báº£o chá»‰ cÃ³ má»™t instance cá»§a class nÃ y
     *
     * GIáº¢I THÃCH:
     * - Kiá»ƒm tra náº¿u instance chÆ°a Ä‘Æ°á»£c táº¡o thÃ¬ táº¡o má»›i
     * - Láº§n sau gá»i chá»‰ tráº£ vá» instance cÅ©
     * - Thread-safe pattern: kiá»ƒm tra rá»“i táº¡o
     *
     * @return Instance duy nháº¥t cá»§a CapNhatThongTinNguoiDung
     */
    private static volatile UserProfileUpdater instance;
    public static UserProfileUpdater getInstance() {
        if (instance == null) {
            synchronized (UserProfileUpdater.class) {
                if (instance == null) instance = new UserProfileUpdater();
            }
        }
        return instance;
    }

    /**
     * PHÆ¯Æ NG THá»¨C: updateUser(Map<String, String> updates)
     * Má»¤C ÄÃCH: Cáº­p nháº­t nhiá»u trÆ°á»ng thÃ´ng tin cá»§a ngÆ°á»i dÃ¹ng cÃ¹ng lÃºc
     *
     * GIáº¢I THÃCH CHI TIáº¾T:
     * 1. Láº¥y ngÆ°á»i dÃ¹ng hiá»‡n táº¡i tá»« SessionManager
     * 2. Kiá»ƒm tra xem ngÆ°á»i dÃ¹ng Ä‘Ã£ Ä‘Äƒng nháº­p hay chÆ°a
     * 3. Cáº­p nháº­t cÃ¡c trÆ°á»ng tÆ°Æ¡ng á»©ng náº¿u cÃ³ trong map
     * 4. â­ LÆ¯U VÃ€O FILE JSON - QUAN TRá»ŒNG NHáº¤T (náº¿u khÃ´ng sáº½ máº¥t dá»¯ liá»‡u)
     * 5. Táº¡o token JWT má»›i vá»›i thÃ´ng tin Ä‘Ã£ cáº­p nháº­t
     * 6. Cáº­p nháº­t SessionManager vá»›i dá»¯ liá»‡u má»›i
     * 7. LÆ°u token vÃ o Preferences Ä‘á»ƒ session bá»n vá»¯ng
     *
     * CÃC TRÆ¯á»œNG CÃ“ THá»‚ Cáº¬P NHáº¬T:
     * - "name": TÃªn ngÆ°á»i dÃ¹ng (Há» vÃ  tÃªn)
     * - "phone": Sá»‘ Ä‘iá»‡n thoáº¡i
     * - "address": Äá»‹a chá»‰
     * - "bankAccount": Sá»‘ tÃ i khoáº£n ngÃ¢n hÃ ng
     * - "balance": Sá»‘ dÆ° kháº£ dá»¥ng (pháº£i lÃ  sá»‘)
     * - "bankName": TÃªn ngÃ¢n hÃ ng
     * - "avatar": ÄÆ°á»ng dáº«n hÃ¬nh áº£nh avatar
     *
     * @param updates Map chá»©a cáº·p key-value cá»§a cÃ¡c trÆ°á»ng cáº§n cáº­p nháº­t
     *                VÃ­ dá»¥: updates.put("name", "Nguyá»…n VÄƒn A");
     */
    public void updateUser(Map<String, String> updates) {
        try {
            // ðŸ”¹ BÆ¯á»šC 1: Láº¥y ngÆ°á»i dÃ¹ng hiá»‡n táº¡i tá»« session
            // SessionManager lÆ°u trá»¯ thÃ´ng tin ngÆ°á»i dÃ¹ng Ä‘Ã£ Ä‘Äƒng nháº­p
            User currentUser = SessionManager.getInstance().getCurrentUser();

            // ðŸ”¹ BÆ¯á»šC 2: Kiá»ƒm tra ngÆ°á»i dÃ¹ng tá»“n táº¡i
            // Náº¿u null = chÆ°a Ä‘Äƒng nháº­p, khÃ´ng thá»ƒ cáº­p nháº­t
            if (currentUser == null) {
                HandleNavigationAndAlert.getInstance().showAlert(Alert.AlertType.ERROR, "Lá»—i", "Báº¡n chÆ°a Ä‘Äƒng nháº­p!");
                return;
            }

            // ðŸ”¹ BÆ¯á»šC 3: Cáº­p nháº­t tá»«ng trÆ°á»ng náº¿u cÃ³ trong map
            // DÃ¹ng containsKey() Ä‘á»ƒ kiá»ƒm tra trÆ°á»›c khi cáº­p nháº­t

            if (updates.containsKey("name")) {
                currentUser.setFullName(updates.get("name"));
            }
            if (updates.containsKey("phone")) {
                currentUser.setPhoneNumber(updates.get("phone"));
            }
            if (updates.containsKey("address")) {
                currentUser.setAddress(updates.get("address"));
            }
            if (updates.containsKey("bankAccount")) {
                currentUser.setBankAccountNumber(updates.get("bankAccount"));
            }
            if (updates.containsKey("balance")) {
                // Chuyá»ƒn tá»« String sang Double Ä‘á»ƒ lÆ°u sá»‘
                currentUser.setAvailableBalance(Double.parseDouble(updates.get("balance")));
            }
            if (updates.containsKey("actualBalance")) {
                currentUser.setActualBalance(Double.parseDouble(updates.get("actualBalance")));
            }
            if (updates.containsKey("bankName")) {
                currentUser.setBankName(updates.get("bankName"));
            }
            if (updates.containsKey("avatar")) {
                currentUser.setAvatarPath(updates.get("avatar"));
            }

            // ðŸ”¹ BÆ¯á»šC 4a: â­ LÆ¯U VÃ€O FILE JSON - QUAN TRá»ŒNG NHáº¤T!!!
            // Náº¿u bá» qua bÆ°á»›c nÃ y, dá»¯ liá»‡u chá»‰ thay Ä‘á»•i trong RAM
            // Khi app Ä‘Ã³ng, táº¥t cáº£ thay Ä‘á»•i sáº½ máº¥t vÄ©nh viá»…n
            // capNhatNguoiDung() sáº½ cáº­p nháº­t báº£n ghi cÅ© (giá»¯ nguyÃªn ID)
            userRepository.update(currentUser);

            // ðŸ”¹ BÆ¯á»šC 4b: Äá»’NG Bá»˜ Sá» DÆ¯ LÃŠN SERVER CHUNG
            if (updates.containsKey("balance") || updates.containsKey("actualBalance")) {
                String token = prefs.get("auth_token", null);
                if (token != null && !token.isEmpty()) {
                    boolean serverUpdated = com.mycompany.utils.ApiClient.updateBalance(
                        currentUser.getEmail(),
                        currentUser.getActualBalance(),
                        token
                    );
                    if (!serverUpdated) {
                        org.slf4j.LoggerFactory.getLogger(UserProfileUpdater.class)
                            .warn("[UserProfileUpdater] âš ï¸ KhÃ´ng thá»ƒ Ä‘á»“ng bá»™ sá»‘ dÆ° lÃªn server.");
                    }
                }
            }

            if (updates.containsKey("bankAccount") || updates.containsKey("bankName")) {
                String token = prefs.get("auth_token", null);
                if (token != null && !token.isEmpty()) {
                    boolean serverUpdated = com.mycompany.utils.ApiClient.updateBankAccount(
                        currentUser.getEmail(),
                        currentUser.getBankAccountNumber(),
                        currentUser.getBankName(),
                        token
                    );
                    if (!serverUpdated) {
                        org.slf4j.LoggerFactory.getLogger(UserProfileUpdater.class)
                            .warn("[UserProfileUpdater] KhÃ´ng thá»ƒ Ä‘á»“ng bá»™ STK lÃªn server.");
                    }
                }
            }

            // ðŸ”¹ BÆ¯á»šC 5: Táº¡o token JWT má»›i vá»›i dá»¯ liá»‡u Ä‘Ã£ cáº­p nháº­t
            // Token chá»©a táº¥t cáº£ thÃ´ng tin ngÆ°á»i dÃ¹ng dÆ°á»›i dáº¡ng Base64
            // ÄÆ°á»£c sá»­ dá»¥ng Ä‘á»ƒ xÃ¡c thá»±c vÃ  kiá»ƒm tra quyá»n
            String newToken = TokenUtil.generateToken(currentUser);

            // ðŸ”¹ BÆ¯á»šC 6: Cáº­p nháº­t SessionManager vá»›i dá»¯ liá»‡u má»›i
            // CÃ¡c controller khÃ¡c cÃ³ thá»ƒ láº¥y thÃ´ng tin tá»« SessionManager
            SessionManager.getInstance().setSession(currentUser, newToken);

            // ðŸ”¹ BÆ¯á»šC 7: LÆ°u token vÃ o Preferences
            // Preferences tá»“n táº¡i ngay cáº£ sau khi app Ä‘Ã³ng
            // Láº§n tá»›i má»Ÿ app, cÃ³ thá»ƒ khÃ´i phá»¥c session tá»« token nÃ y
            prefs.put("auth_token", newToken);

        } catch (Exception e) {
            // Báº¯t táº¥t cáº£ exception vÃ  hiá»ƒn thá»‹ cho ngÆ°á»i dÃ¹ng
            HandleNavigationAndAlert.getInstance().showAlert(Alert.AlertType.ERROR, "Lá»—i cáº­p nháº­t", "KhÃ´ng thá»ƒ cáº­p nháº­t thÃ´ng tin ngÆ°á»i dÃ¹ng! " + e.getMessage());
        }
    }

}

