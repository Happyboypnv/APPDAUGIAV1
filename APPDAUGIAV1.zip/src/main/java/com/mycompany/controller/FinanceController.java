package com.mycompany.controller;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import com.mycompany.action.FinanceAction;
import com.mycompany.action.HandleNavigationAndAlert;
import com.mycompany.models.User;
import com.mycompany.utils.UserProfileUpdater;
import com.mycompany.utils.SessionManager;
import com.mycompany.utils.UserRepositorySQLite;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;

import javafx.scene.image.ImageView;

/**
 * FinanceController - Controller quáº£n lÃ½ trang TÃ i chÃ­nh (Finance Management)
 *
 * Má»¤C ÄÃCH:
 * - Quáº£n lÃ½ cÃ¡c chá»©c nÄƒng tÃ i chÃ­nh cá»§a ngÆ°á»i dÃ¹ng
 * - LiÃªn káº¿t tÃ i khoáº£n ngÃ¢n hÃ ng
 * - Náº¡p tiá»n (deposit) vÃ  rÃºt tiá»n (withdraw)
 * - Hiá»ƒn thá»‹ sá»‘ dÆ° hiá»‡n táº¡i
 * - Cáº­p nháº­t thÃ´ng tin tÃ i chÃ­nh vÃ o há»‡ thá»‘ng
 *
 * TÃNH NÄ‚NG CHÃNH:
 * - LiÃªn káº¿t tÃ i khoáº£n ngÃ¢n hÃ ng vá»›i validation
 * - Náº¡p tiá»n vÃ o tÃ i khoáº£n
 * - RÃºt tiá»n tá»« tÃ i khoáº£n
 * - Hiá»ƒn thá»‹ sá»‘ dÆ° real-time
 * - Validation input (sá»‘ tÃ i khoáº£n, sá»‘ tiá»n)
 * - Cáº­p nháº­t dá»¯ liá»‡u vÃ o JSON file
 *
 * LUá»’NG HOáº T Äá»˜NG:
 * 1. Load trang â†’ Hiá»ƒn thá»‹ thÃ´ng tin tÃ i chÃ­nh hiá»‡n táº¡i
 * 2. NgÆ°á»i dÃ¹ng nháº­p thÃ´ng tin ngÃ¢n hÃ ng â†’ Validate â†’ LÆ°u
 * 3. NgÆ°á»i dÃ¹ng náº¡p/rÃºt tiá»n â†’ Validate â†’ Cáº­p nháº­t sá»‘ dÆ°
 * 4. Tá»± Ä‘á»™ng refresh UI sau má»—i thao tÃ¡c
 */
public class FinanceController implements Initializable {

    // @FXML FIELDS - CÃ¡c thÃ nh pháº§n UI Ä‘Æ°á»£c inject tá»« FXML
    @FXML private TextField  bankAccount, // Sá»‘ tÃ i khoáº£n ngÃ¢n hÃ ng
                             depositField, // Ã” nháº­p sá»‘ tiá»n náº¡p
                             withdrawField, // Ã” nháº­p sá»‘ tiá»n rÃºt
                             currentBalanceField; // Hiá»ƒn thá»‹ sá»‘ dÆ° hiá»‡n táº¡i

    @FXML private ComboBox<String> banks; // Dropdown chá»n ngÃ¢n hÃ ng

    @FXML private Button linkToBankButton, // NÃºt liÃªn káº¿t ngÃ¢n hÃ ng
                         depositButton, // NÃºt náº¡p tiá»n
                         withdrawButton; // NÃºt rÃºt tiá»n

    @FXML ImageView editBankAccountBtn; // NÃºt edit sá»‘ tÃ i khoáº£n

    /**
     * PHÆ¯Æ NG THá»¨C: initialize(URL url, ResourceBundle resourceBundle)
     * Má»¤C ÄÃCH: Khá»Ÿi táº¡o trang Finance khi load
     *
     * GIáº¢I THÃCH CHI TIáº¾T:
     * 1. ThÃªm danh sÃ¡ch ngÃ¢n hÃ ng vÃ o ComboBox
     * 2. Láº¥y thÃ´ng tin ngÆ°á»i dÃ¹ng tá»« token
     * 3. Hiá»ƒn thá»‹ sá»‘ dÆ° vÃ  thÃ´ng tin ngÃ¢n hÃ ng Ä‘Ã£ liÃªn káº¿t
     *
     * @param url URL cá»§a FXML file
     * @param resourceBundle ResourceBundle (cÃ³ thá»ƒ null)
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // ðŸ”¹ BÆ¯á»šC 1: ThÃªm danh sÃ¡ch ngÃ¢n hÃ ng vÃ o ComboBox
        banks.getItems().addAll("MB Bank", "Techcombank", "BIDV", "Agribank", "VP Bank"); // Lá»±a chá»n ngÃ¢n hÃ ng

        User user = SessionManager.getInstance().getCurrentUser();
        if (user != null) {
            user = reloadCurrentUser(user);
            currentBalanceField.setText(String.format("%,.0f VNĐ", user.getActualBalance()));
            bankAccount.setText(user.getBankAccountNumber());
            if (user.getBankName() != null) {
                banks.setValue(user.getBankName());
            }
        }
    }

    /**
     * PHÆ¯Æ NG THá»¨C: onClickedEditBankAccount()
     * Má»¤C ÄÃCH: Cho phÃ©p chá»‰nh sá»­a sá»‘ tÃ i khoáº£n ngÃ¢n hÃ ng
     *
     * GIáº¢I THÃCH:
     * - Gá»i FinanceAction Ä‘á»ƒ enable/disable editing mode
     * - Khi edit = true: cho phÃ©p nháº­p text
     * - Khi edit = false: disable nháº­p, chá»‰ view
     */
    @FXML
    public void onClickedEditBankAccount() {
        FinanceAction.getInstance().editBankAccount(bankAccount, true);
    }

    /**
     * PHÆ¯Æ NG THá»¨C: onClickedLinkToBank()
     * Má»¤C ÄÃCH: LiÃªn káº¿t tÃ i khoáº£n ngÃ¢n hÃ ng vá»›i validation
     *
     * GIáº¢I THÃCH CHI TIáº¾T:
     * 1. Validate sá»‘ tÃ i khoáº£n (10-15 chá»¯ sá»‘)
     * 2. Validate Ä‘Ã£ chá»n ngÃ¢n hÃ ng
     * 3. Disable editing mode
     * 4. Cáº­p nháº­t thÃ´ng tin vÃ o há»‡ thá»‘ng
     * 5. Hiá»ƒn thá»‹ thÃ´ng bÃ¡o thÃ nh cÃ´ng
     */
    @FXML
    public void onClickedLinkToBank() {
        // ðŸ”¹ BÆ¯á»šC 1: Validate sá»‘ tÃ i khoáº£n
        String bankAccountRegex = "^\\d{10,15}$"; // Regex: 10-15 chá»¯ sá»‘
        String bankAcc = bankAccount.getText().trim();

        // Kiá»ƒm tra format sá»‘ tÃ i khoáº£n
        if (bankAcc == null || bankAcc.isEmpty() || !bankAcc.matches(bankAccountRegex)) {
            HandleNavigationAndAlert.getInstance().showAlert(
                    Alert.AlertType.ERROR, "Lá»—i thÃ´ng tin",
                    "Sá»‘ tÃ i khoáº£n ngÃ¢n hÃ ng khÃ´ng há»£p lá»‡ (10-15 chá»¯ sá»‘).");
            return;
        }

        // Kiá»ƒm tra Ä‘Ã£ chá»n ngÃ¢n hÃ ng
        String customBoxBankName = banks.getValue();
        if (customBoxBankName == null) {
            HandleNavigationAndAlert.getInstance().showAlert(Alert.AlertType.ERROR, "Lá»—i thÃ´ng tin", "Vui lÃ²ng chá»n ngÃ¢n hÃ ng!");
            return;
        }

        // ðŸ”¹ BÆ¯á»šC 2: Disable editing mode (lock field)
        FinanceAction.getInstance().editBankAccount(bankAccount, false);

        // ðŸ”¹ BÆ¯á»šC 3: Cáº­p nháº­t thÃ´ng tin ngÃ¢n hÃ ng
        Map<String, String> newBankAcc = new HashMap<>();
        newBankAcc.put("bankAccount", bankAcc);
        newBankAcc.put("bankName", customBoxBankName);

        // LÆ°u vÃ o JSON file vÃ  cáº­p nháº­t session
        UserProfileUpdater.getInstance().updateUser(newBankAcc);

        // ðŸ”¹ BÆ¯á»šC 4: ThÃ´ng bÃ¡o thÃ nh cÃ´ng
        HandleNavigationAndAlert.getInstance().showAlert(Alert.AlertType.INFORMATION, "ThÃ nh cÃ´ng", "LiÃªn káº¿t tÃ i khoáº£n ngÃ¢n hÃ ng thÃ nh cÃ´ng!");
    }

    /**
     * PHÆ¯Æ NG THá»¨C: onClickedDeposit()
     * Má»¤C ÄÃCH: Xá»­ lÃ½ náº¡p tiá»n vÃ o tÃ i khoáº£n
     *
     * GIáº¢I THÃCH CHI TIáº¾T:
     * 1. Láº¥y sá»‘ tiá»n tá»« input field
     * 2. Validate sá»‘ tiá»n (pháº£i lÃ  sá»‘)
     * 3. Gá»i FinanceAction.deposit() Ä‘á»ƒ xá»­ lÃ½
     * 4. Clear input field
     * 5. Refresh hiá»ƒn thá»‹ sá»‘ dÆ°
     */
    @FXML
    public void onClickedDeposit() {
        String amountStr = depositField.getText().trim();
        try {
            double amount = Double.parseDouble(amountStr);
            FinanceAction.getInstance().deposit(amount);
        } catch (NumberFormatException e) {
            HandleNavigationAndAlert.getInstance().showAlert(
                    Alert.AlertType.ERROR, "Lá»—i thÃ´ng tin", "Sá»‘ tiá»n khÃ´ng há»£p lá»‡.");
        }
        depositField.clear();
        refreshBalance(); // TÃ¡ch ra hÃ m riÃªng
    }

    // ThÃªm hÃ m helper â€” dÃ¹ng chung cho deposit vÃ  withdraw
    private void refreshBalance() {
        User user = SessionManager.getInstance().getCurrentUser();
        if (user != null) {
            user = reloadCurrentUser(user);
            currentBalanceField.setText(String.format("%,.0f VNĐ", user.getActualBalance()));
        }
    }

    private User reloadCurrentUser(User currentUser) {
        User refreshed = new UserRepositorySQLite().findByEmail(currentUser.getEmail());
        if (refreshed != null) {
            SessionManager.getInstance().setSession(refreshed, SessionManager.getInstance().getCurrentToken());
            return refreshed;
        }
        return currentUser;
    }

    /**
     * PHÆ¯Æ NG THá»¨C: onClickedWithdraw()
     * Má»¤C ÄÃCH: Xá»­ lÃ½ rÃºt tiá»n tá»« tÃ i khoáº£n
     *
     * GIáº¢I THÃCH CHI TIáº¾T:
     * 1. Láº¥y sá»‘ tiá»n tá»« input field
     * 2. Validate sá»‘ tiá»n (pháº£i lÃ  sá»‘)
     * 3. Gá»i FinanceAction.withdraw() Ä‘á»ƒ xá»­ lÃ½
     * 4. Clear input field
     * 5. Refresh hiá»ƒn thá»‹ sá»‘ dÆ°
     */
    @FXML
    public void onClickedWithdraw() {
        String amountStr = withdrawField.getText().trim();
        try {
            double amount = Double.parseDouble(amountStr);
            FinanceAction.getInstance().withdraw(amount);
        } catch (NumberFormatException e) {
            HandleNavigationAndAlert.getInstance().showAlert(
                    Alert.AlertType.ERROR, "Lá»—i thÃ´ng tin", "Sá»‘ tiá»n khÃ´ng há»£p lá»‡.");
        }
        withdrawField.clear();
        refreshBalance(); // DÃ¹ng láº¡i
    }
}



