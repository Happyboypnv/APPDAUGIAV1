package com.mycompany.models;

public enum SessionStatus {
    WAITING, IN_PROGRESS, PAYMENT_PENDING, PAID, CANCELLED
}
