package com.mycompany.action;

import com.mycompany.models.AuctionSession;
import com.mycompany.models.SessionStatus;

import java.time.LocalDateTime;
import java.util.concurrent.*;
import java.util.*;

public class AuctionScheduler {
    private static volatile AuctionScheduler instance;

    private AuctionScheduler() {}

    public static AuctionScheduler getInstance() {
        if (instance == null) {
            synchronized (AuctionScheduler.class) {
                if (instance == null) {
                    instance = new AuctionScheduler();
                }
            }
        }
        return instance;
    }

    private final ScheduledExecutorService executor = Executors.newScheduledThreadPool(3, runnable -> {
        Thread task = new Thread(runnable);
        task.setDaemon(false);
        return task;
    });

    private final Map<String, ScheduledFuture<?>> acFutures = new ConcurrentHashMap<>();
    private final Map<String, ScheduledFuture<?>> asFutures = new ConcurrentHashMap<>();
    private final AuctionSessionService auctionSessionService = AuctionSessionService.getInstance();

    /**
     * Lên lịch tự động chuyển trạng thái AuctionSession từ WAITING → IN_PROGRESS
     * khi đến đúng thời gian startTime của phiên.
     *
     * @param phien phiên đấu giá cần lên lịch mở
     */
    public void setASAuction(AuctionSession phien) {
        String maPhien = phien.getSessionId();
        if (phien.getStartTime() == null) return;

        long delay = java.time.Duration.between(LocalDateTime.now(), phien.getStartTime()).toSeconds();
        if (delay <= 0) return;

        // Hủy lịch cũ nếu đã tồn tại
        ScheduledFuture<?> existing = asFutures.remove(maPhien);
        if (existing != null && !existing.isDone()) {
            existing.cancel(false);
        }

        ScheduledFuture<?> future = executor.schedule(() -> {
            auctionSessionService.start(phien);
            asFutures.remove(maPhien);
        }, delay, TimeUnit.SECONDS);

        asFutures.put(maPhien, future);
    }

    /**
     * Hủy lịch tự động mở phiên (nếu cần hủy phiên trước khi bắt đầu).
     *
     * @param phien phiên đấu giá cần hủy lịch mở
     */
    public void cancelAS(AuctionSession phien) {
        String maPhien = phien.getSessionId();

        ScheduledFuture<?> future = asFutures.remove(maPhien);
        if (future != null && !future.isDone()) {
            future.cancel(false);
        }
    }

    public void setACAuction(AuctionSession phien) {
        String maPhien = phien.getSessionId();
        long delay = java.time.Duration.between(LocalDateTime.now(), phien.getEndTime()).toSeconds();
        if (delay <= 0) return;

        cancelAC(phien);

        ScheduledFuture<?> future = executor.schedule(() -> closeAuction(phien), delay, TimeUnit.SECONDS);
        acFutures.put(maPhien, future);
    }
    public void cancelAC(AuctionSession phien) {
        String maPhien = phien.getSessionId();

        ScheduledFuture<?> future = acFutures.remove(maPhien);
        if(future != null && !future.isDone()) {
            future.cancel(false);
        }
    }
    public void closeAuction(AuctionSession phien) {
        String maPhien = phien.getSessionId();

        auctionSessionService.closeAuction(phien, SessionStatus.PAID);
        acFutures.remove(maPhien);
    }
    public void shutdown() {
        executor.shutdown();
    }
}