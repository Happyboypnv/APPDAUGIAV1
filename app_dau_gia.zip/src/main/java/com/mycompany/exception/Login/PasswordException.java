package com.mycompany.exception.Login;

public class PasswordException extends Exception{
    public PasswordException(String message){
        super(message);
    }
}
