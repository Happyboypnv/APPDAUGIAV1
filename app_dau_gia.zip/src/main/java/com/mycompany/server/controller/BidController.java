package com.mycompany.server.controller;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mycompany.action.AuctionSessionService;
import com.mycompany.models.*;
import com.mycompany.utils.IUserRepository;
import com.mycompany.utils.IAuctionRepository;
import com.mycompany.utils.UserRepositorySQLite;
import com.mycompany.utils.AuctionRepositorySQLite;
import com.sun.net.httpserver.HttpExchange;
import com.mycompany.server.dto.DatGiaRequest;
import com.mycompany.server.dto.DatGiaResponse;
import com.mycompany.server.dto.LichSuDatGiaResponse;
import com.mycompany.server.dto.LuotDatGia;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * BidController — Xử lý các HTTP request liên quan đến đặt giá (bid).
 *
 * Hai API endpoint:
 *  POST /api/bids               → Đặt giá (validate + lưu thông qua PhienDauGiaService)
 *  GET  /api/bids/{phienId}     → Lịch sử đặt giá của một phiên
 *
 * Tái sử dụng:
 *  - PhienDauGiaService.setPrice()   (singleton, có sẵn) — toàn bộ validate + cập nhật state
 *  - KhoLuuTruPhienDauGiaSQLite    (có sẵn)            — đọc / ghi phiên
 *  - KhoLuuTruNguoiDungSQLite      (có sẵn)            — tra cứu người đặt giá
 *
 * Validate do PhienDauGiaService.setPrice() đảm nhiệm:
 *  ✔ Phiên phải đang diễn ra (DANG_DIEN_RA)
 *  ✔ Người đặt giá không phải người bán
 *  ✔ Giá mới ≥ giaHienTai + buocGia
 *  ✔ Tự động gia hạn nếu còn < 60s
 *
 * Authentication:
 *  - POST yêu cầu Authorization: Bearer <token>
 *  - GET không yêu cầu token (public)
 */
public class BidController {

    // ===== PHỤ THUỘC =====

    private final Gson gson = new GsonBuilder()
            .setPrettyPrinting()
            .serializeNulls()
            .create();

    /** Kho phiên đấu giá — tái sử dụng implementation SQLite đã có */
    private final IAuctionRepository auctionRepository = new AuctionRepositorySQLite();

    /** Kho người dùng — để tra cứu người đặt giá từ token */
    private final IUserRepository userRepository = new UserRepositorySQLite();

    /** Service đấu giá — tái sử dụng singleton đã có, KHÔNG tạo mới */
    private final AuctionSessionService auctionSessionService = AuctionSessionService.getInstance();

    // =========================================================
    // ROUTING
    // =========================================================

    /**
     * Điểm vào duy nhất cho mọi request đến /api/bids
     *
     * Routing:
     *   POST /api/bids            → handleDatGia()
     *   GET  /api/bids/{phienId}  → handleLayLichSu()
     */
    public void route(HttpExchange exchange) throws IOException {
        String method = exchange.getRequestMethod().toUpperCase();
        String path   = exchange.getRequestURI().getPath();

        if (path.endsWith("/") && path.length() > 1) {
            path = path.substring(0, path.length() - 1);
        }

        // POST /api/bids → đặt giá
        if (method.equals("POST") && path.equals("/api/bids")) {
            handleSetPrice(exchange);
            return;
        }

        // GET /api/bids/{phienId} → lịch sử đặt giá
        if (method.equals("GET") && path.startsWith("/api/bids/")) {
            String maPhien = path.substring("/api/bids/".length());
            handleLayLichSu(exchange, maPhien);
            return;
        }

        guiPhanHoi(exchange, 404, bug("Endpoint không tồn tại: " + method + " " + path));
    }

    // =========================================================
    // API 1: POST /api/bids  →  đặt giá
    // =========================================================

    /**
     * Đặt giá cho một phiên đấu giá đang diễn ra.
     *
     * Yêu cầu: Authorization: Bearer <token>
     *
     * Request body:
     * {
     *   "maPhien": "PH000001",
     *   "gia": 750000
     * }
     *
     * Quy trình:
     *  1. Xác thực token → lấy NguoiDung người đặt giá
     *  2. Tìm phiên theo maPhien
     *  3. Gọi PhienDauGiaService.setPrice() — validate toàn bộ và cập nhật state
     *  4. Nếu setPrice thành công, lưu lại phiên vào SQLite
     *
     * Response 200: { "thongBao": "Đặt giá thành công", "giaHienTai": 750000 }
     * Response 400: { "bug": "Giá đặt phải ≥ giaKhoiDiem + buocGia" }
     * Response 401: { "bug": "Cần đăng nhập trước" }
     * Response 404: { "bug": "Không tìm thấy phiên: PH999999" }
     * Response 409: { "bug": "Phiên không ở trạng thái DANG_DIEN_RA" }
     */
    private void handleSetPrice(HttpExchange exchange) throws IOException {
        // Bước 1: Xác thực token → lấy người đặt giá
        User nguoiDat = checkToken(exchange);
        if (nguoiDat == null) return;

        // Bước 2: Đọc và parse body
        String body = readBody(exchange);
        DatGiaRequest req = gson.fromJson(body, DatGiaRequest.class);

        if (req == null || req.getMaPhien() == null || req.getGia() <= 0) {
            guiPhanHoi(exchange, 400, bug("Thiếu hoặc sai thông tin: maPhien, gia (>0)"));
            return;
        }

        // Bước 3: Tìm phiên
        AuctionSession phien = auctionRepository.findById(req.getMaPhien());
        if (phien == null) {
            guiPhanHoi(exchange, 404, bug("Không tìm thấy phiên: " + req.getMaPhien()));
            return;
        }

        // Bước 4: Kiểm tra nhanh trạng thái trước khi gọi service
        // (service cũng kiểm tra bên trong, nhưng ta cần phân biệt lỗi để trả HTTP code đúng)
        if (phien.getStatus() != SessionStatus.IN_PROGRESS) {
            guiPhanHoi(exchange, 409, bug(
                    "Phiên không ở trạng thái DANG_DIEN_RA. Trạng thái hiện tại: " + phien.getStatus().name()));
            return;
        }

        // Bước 5: Kiểm tra người bán tự đặt giá
        if (nguoiDat.getUserId().equals(phien.getSeller().getUserId())) {
            guiPhanHoi(exchange, 400, bug("Người bán không thể tự đặt giá cho phiên của mình"));
            return;
        }

        // Bước 6: Kiểm tra giá hợp lệ trước khi gọi service
        double giaToiThieu = phien.getCurrentPrice() + phien.getPriceStep();
        if (req.getGia() < giaToiThieu) {
            guiPhanHoi(exchange, 400, bug(String.format(
                    "Giá đặt phải ≥ %.0f (giaHienTai=%.0f + buocGia=%.0f)",
                    giaToiThieu, phien.getCurrentPrice(), phien.getPriceStep())));
            return;
        }
        // Bước 8: Kiểm tra setPrice có thực sự thành công không
        // (service silently return nếu fail — ta so sánh giaHienTai trước/sau)
        boolean success = auctionSessionService.setPrice(phien, nguoiDat, req.getGia());
        if (!success) {
            guiPhanHoi(exchange, 400, bug("Đặt giá thất bại. Vui lòng kiểm tra lại giá hoặc trạng thái phiên."));
            return;
        }
        // Bước 9: Lưu trạng thái phiên đã cập nhật vào SQLite
        auctionRepository.update(phien);

        guiPhanHoi(exchange, 200, gson.toJson(new DatGiaResponse(
                "Đặt giá thành công",
                phien.getCurrentPrice(),
                phien.getEndTime() != null ? phien.getEndTime().toString() : null
        )));
    }

    // =========================================================
    // API 2: GET /api/bids/{phienId}  →  lịch sử đặt giá
    // =========================================================

    /**
     * Trả về lịch sử đặt giá của một phiên (danh sách người đã đặt giá).
     *
     * Lưu ý: danhSachNguoiTraGia trong PhienDauGia hiện lưu theo thứ tự thêm vào.
     *        Người cuối cùng trong danh sách = người đang thắng.
     *        Dữ liệu trong memory — SQLite chưa có bảng riêng cho từng lượt đặt giá.
     *
     * Response 200:
     * {
     *   "maPhien": "PH000001",
     *   "giaHienTai": 750000,
     *   "trangThai": "DANG_DIEN_RA",
     *   "soLuotDatGia": 3,
     *   "nguoiDangThang": "Nguyen Van B",
     *   "lichSu": [
     *     { "stt": 1, "tenNguoiDat": "Nguyen Van B" },
     *     { "stt": 2, "tenNguoiDat": "Tran Thi C" },
     *     { "stt": 3, "tenNguoiDat": "Nguyen Van B" }
     *   ]
     * }
     *
     * Response 404: { "bug": "Không tìm thấy phiên: PH999999" }
     */
    private void handleLayLichSu(HttpExchange exchange, String maPhien) throws IOException {
        if (maPhien == null || maPhien.isBlank()) {
            guiPhanHoi(exchange, 400, bug("Thiếu mã phiên trong URL"));
            return;
        }

        AuctionSession phien = auctionRepository.findById(maPhien);
        if (phien == null) {
            guiPhanHoi(exchange, 404, bug("Không tìm thấy phiên: " + maPhien));
            return;
        }

        List<User> danhSach = phien.getBidderList();

        // Xây dựng lịch sử — mỗi entry là một lượt đặt giá
        List<LuotDatGia> lichSu = new ArrayList<>();
        for (int i = 0; i < danhSach.size(); i++) {
            lichSu.add(new LuotDatGia(i + 1, danhSach.get(i).getFullName(), danhSach.get(i).getUserId()));
        }

        // Người đang thắng = người cuối trong danh sách
        String tenNguoiDangThang = null;
        if (!danhSach.isEmpty()) {
            tenNguoiDangThang = danhSach.get(danhSach.size() - 1).getFullName();
        }

        LichSuDatGiaResponse response = new LichSuDatGiaResponse(
                maPhien,
                phien.getCurrentPrice(),
                phien.getStatus().name(),
                danhSach.size(),
                tenNguoiDangThang,
                lichSu
        );

        guiPhanHoi(exchange, 200, gson.toJson(response));
    }

    // =========================================================
    // PHƯƠNG THỨC HỖ TRỢ
    // =========================================================

    /**
     * Xác thực Bearer token và trả về NguoiDung tương ứng.
     * Token format: "USER_<email>_<timestamp>"
     *
     * @return NguoiDung nếu hợp lệ, null nếu không (đã gửi response lỗi)
     */
    private User checkToken(HttpExchange exchange) throws IOException {
        String authHeader = exchange.getRequestHeaders().getFirst("Authorization");

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            guiPhanHoi(exchange, 401, bug("Cần đăng nhập trước (Authorization: Bearer <token>)"));
            return null;
        }

        String token = authHeader.substring("Bearer ".length()).trim();

        if (!token.startsWith("USER_")) {
            guiPhanHoi(exchange, 401, bug("Token không hợp lệ"));
            return null;
        }

        String phan = token.substring("USER_".length());
        int lastUnderscore = phan.lastIndexOf('_');

        if (lastUnderscore < 0) {
            guiPhanHoi(exchange, 401, bug("Token không hợp lệ"));
            return null;
        }

        String email = phan.substring(0, lastUnderscore);

        User nguoiDung = userRepository.findByEmail(email);

        if (nguoiDung == null) {
            guiPhanHoi(exchange, 401, bug("Token không hợp lệ hoặc tài khoản không tồn tại"));
            return null;
        }

        return nguoiDung;
    }

    private String readBody(HttpExchange exchange) throws IOException {
        InputStream is = exchange.getRequestBody();
        return new String(is.readAllBytes(), StandardCharsets.UTF_8);
    }

    private String bug(String thongBao) {
        return gson.toJson(new sendBug(thongBao));
    }

    private void guiPhanHoi(HttpExchange exchange, int statusCode, String jsonBody) throws IOException {
        byte[] bytes = jsonBody.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().add("Content-Type", "application/json; charset=UTF-8");
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin",  "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type, Authorization");
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }
    private static class sendBug {
        String bug;
        sendBug(String bug) { this.bug = bug; }
    }
}